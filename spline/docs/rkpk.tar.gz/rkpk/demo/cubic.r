#   THIS PROGRAM ILLUSTRATES THE USE OF RKPACK ROUTINES IN FITTING A MODEL
#        y = f(x) + e
#   ON [0,1] USING CUBIC SPLINES.  THE PROGRAM CALCULATES THE FIT BASED ON
#   IRREGULAR DATA AND CALCULATES POSTERIOR MEAN AND POSTERIOR STANDARD
#   DEVIATION ON A REGULAR GRID AS OUTPUT.

program  cubic

parameter  ( nobs = 100, nnull = 2, ngrid = 101 )

#   PARAMETERS:
#        nobs     number of observations. 
#        nnull    dimension of null space.
#        ngrid    number of grid points for output

double precision  x(nobs), s(nobs,nnull), qraux(nnull), q(nobs,nobs), y(nobs),_
                  nlaht, score, varht, b, c(nobs), d(nnull), wk(3*nobs), limnla(2),_
                  xx(ngrid), r(nobs,ngrid), cr(nobs,ngrid), dr(nnull,ngrid),_
                  sms(nnull,nnull), tmp, rc, df, ddot, nsize
real              uni, rnor
integer           info, i, j, jpvt(nnull), dseed, nseed, infosv


#   INPUT SIMULATION PARAMETERS
read (*,*) dseed, nseed, nsize    #SEED FOR DESIGN, SEED FOR NOISE, STD OF NOISE
write (*,*) 'Number of observations', nobs
write (*,*) 'Number of grid points', ngrid
write (*,*) 'Seed for uniform design', dseed
write (*,*) 'Seed for Gaussian noise', nseed
write (*,*) 'Standard deviation of noise', sngl (nsize)

#   GENERATE THE DESIGN
tmp = dble (uni (dseed))
for (j=1;j<=nobs;j=j+1)  x(j) = dble (uni (0))

#   GENERATE THE MATRIX S
call  dset (nobs, 1.d0, s(1,1), 1)
for (j=1;j<=nobs;j=j+1)  s(j,2) = x(j) - .5d0

#   GENERATE THE MATRIX Q
for (j=1;j<=nobs;j=j+1) {
    for (i=j;i<=nobs;i=i+1)  q(i,j) = rc (x(i), x(j))   # rc IS APPENDED AT THE END
}

#   GENERATE THE RESPONSE y
tmp = dble (rnor (nseed))
for (j=1;j<=nobs;j=j+1)  y(j) = df (x(j)) + dble (rnor (0)) * nsize   # df APPENDED AT THE END

#   CALL RKPACK DRIVER FOR MODEL FITTING
call  dsidr ('v', s, nobs, nobs, nnull, y, q, nobs, 0.d0, 0, limnla,_
             nlaht, score, varht, c, d, qraux, jpvt, wk, info)
infosv = info

#   CALCULATE b
b = varht / 10.d0**nlaht

#   SET GRID
for (j=1;j<=ngrid;j=j+1)  xx(j) = 0.d0 + dfloat (j-1) / dfloat (ngrid-1)

#   GENERATE R FOR CALCULATING c_r AND d_r
for (i=1;i<=nobs;i=i+1) {
    for (j=1;j<=ngrid;j=j+1)  r(i,j) = rc (x(i), xx(j))
}

#   CALCULATE c_r, d_r, AND sms
call  dcrdr (s, nobs, nobs, nnull, qraux, jpvt, q, nobs, nlaht,_
             r, nobs, ngrid, cr, nobs, dr, nnull, wk, info)
call  dsms (s, nobs, nobs, nnull, jpvt, q, nobs, nlaht,_
            sms, nnull, wk, info)

#   GENERATE R FOR ESTIMATE EVALUATION
for (i=1;i<=nobs;i=i+1) {
    for (j=1;j<=ngrid;j=j+1)  r(i,j) = rc (x(i), xx(j))
}

#   OUTPUT VAR ESTIMATE AND INFO FROM dsidr
write (*,*)  'Info from dsidr =', infosv, 'log10(n lambda) =', sngl (nlaht),_
             'Sigma hat =', sngl (sqrt (varht))
#   OUTPUT TEST FUNCTION, POSTERIOR MEAN, AND POSTERIOR STANDARD DEVIATION ON GRID
write (*,*)  'Grid	Truth	Estimate	Posterior std'
for (j=1;j<=ngrid;j=j+1) {
    #   TEST FUNCTION
    wk(1) = df (xx(j))
    #   POSTERIOR MEAN
    wk(2) = d(1) + d(2) * (xx(j) - .5d0) + ddot (nobs, r(1,j), 1, c, 1)
    #   POSTERIOR STANDARD DEVIATION
    wk(3) = sms(1,1) + 2.d0 * sms(2,1) * (xx(j) - .5d0) + sms(2,2) * (xx(j) - .5d0)**2_
           + rc (xx(j), xx(j)) - ddot (nobs, r(1,j), 1, cr(1,j), 1)_
           - 2.d0 * dr(1,j) - 2.d0 * (xx(j) - .5d0) * dr(2,j)
    wk(3) = dsqrt (b*wk(3))
    write (*,*)  sngl (xx(j)), (sngl (wk(i)), i=1,3)
}

stop
end


#   TEST FUNCTION
double precision function  df (x)
double precision  x

df = 1.d6 * (x ** 11 * (1 - x) ** 6) + 1.d4 * (x ** 3 * (1 - x) ** 10)

return
end 


#   REPRODUCING KERNEL FOR CUBIC SPLINE ON [0,1]
double precision function  rc (y,x)
double precision  y, x, dk2, dk4

rc = dk2 (y) * dk2 (x) - dk4 (x-y)

return
end


#   AUXILIARY FUNCTION FOR CALCULATING REPRODUCING KERNEL
double precision function  dk2 (x)
double precision  x

x = dabs (x)
dk2 = ( x - .5d0 ) ** 2 
dk2 = ( dk2 - 1.d0 / 12.d0 ) / 2.d0

return
end


#   AUXILIARY FUNCTION FOR CALCULATING REPRODUCING KERNEL
double precision function  dk4 (x)
double precision  x

x = dabs (x)
dk4 = ( x - .5d0 ) ** 2
dk4 = ( dk4 ** 2 - dk4 / 2.d0 + 7.d0 / 240.d0 ) / 24.d0

return
end
