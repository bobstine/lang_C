#   THIS PROGRAM ILLUSTRATES THE USE OF RKPACK ROUTINES IN FITTING A MODEL
#        y = C + f1(x1) + f2(x2) + f3(x3) + f12(x1,x2) + e
#   ON [0,1]^3 USING TENSOR PRODUCT SPLINES WITH CUBIC SPLINE SPACE AS MARGINALS
#   AND WITH INTEGRATION SIDE CONDITIONS.  THE PROGRAM CALCULATES THE FIT AND
#   EVALUATES THE POSTERIOR MEAN AND POSTERIOR STANDARD DEVIATION OF THE x1-x2
#   INTERACTION ON A PRODUCT GRID.

program  tensor1

#   CAUTION:  nobs=200 takes a lot of memory
parameter  ( nobs = 100, nnull = 5, nq = 6, k = 3, nrep = 5, ngrid=41 )

#   PARAMETERS:
#        nobs     number of observations. 
#        nnull    dimension of null space.
#        nq       number of smoothing parameters.
#        k        number of variables.
#        nrep     number of replicates requested.
#        ngrid    number of grid points in each margin of [0,1]^2.

double precision  x(nobs,k), s(nobs,nnull), swk(nobs,nnull), q(nobs,nobs,nq),_
                  qwk(nobs,nobs,nq), y(nobs), ywk(nobs), prec, theta(nq), nlaht,_
                  score, varht, b, c(nobs), d(nnull), dwk(nobs*nobs*(nq+2)),_
                  r(nobs,ngrid*ngrid), xx(ngrid), cr(nobs,ngrid*ngrid),_
                  dr(nnull,ngrid*ngrid), qraux(nnull),_
                  sms(nnull,nnull), limnla(2), tmp, rc, dfm, dfi, ddot,_
                  f(nobs,nnull), nsize
real              uni, rnor
integer           info, i, j, ii, jj, jjj, init, maxiter, jpvt(nnull), dseed, nseed, infosv


#   SET ALGORITHMIC PARAMETERS
init = 0
prec = 1.d-6
maxiter = 30

#   INPUT SIMULATION PARAMETERS
read (*,*) dseed, nseed, nsize    #SEED FOR DESIGN, SEED FOR NOISE, STD OF NOISE
write (*,*) '#nobs', nobs
write (*,*) '#dseed', dseed   # 2375 WAS USED IN THE SIMULATIONS
write (*,*) '#nseed', nseed   # 5732 WAS USED IN THE SIMULATIONS
write (*,*) '#nsize', sngl (nsize)   # 1, 3, AND 10 USED IN SIMULATIONS

#   GENERATE THE DESIGN
tmp = dble (uni (dseed))
for (j=1;j<=nobs;j=j+1) {
    for (i=1;i<=k;i=i+1)  x(j,i) = dble (uni (0))
}

#   GENERATE THE TEST FUNCTION
for (j=1;j<=nobs;j=j+1) {
    f(j,2) = dfm (x(j,1), 1)   # dfm AND dfi ARE APPENDED AT THE END OF THIS PROGRAM
    f(j,3) = dfm (x(j,2), 2)
    f(j,4) = dfm (x(j,3), 3)
    f(j,5) = dfi (x(j,1), x(j,2), 1, 2)
    f(j,1) = 1.d0 + f(j,2) + f(j,3) + f(j,4) + f(j,5)
}

#   GENERATE THE MATRIX S
call  dset (nobs, 1.d0, s(1,1), 1)
for (j=1;j<=nobs;j=j+1) {
    s(j,2) = x(j,1) - .5d0    #                      
    s(j,3) = x(j,2) - .5d0    #   MAIN EFFECTS TERMS
    s(j,4) = x(j,3) - .5d0    #                      
    s(j,5) = s(j,2) * s(j,3)    #   x1-x2 INTERACTION TERM
}

#   GENERATE THE MATRICES $\tilde{\Sigma}_{\beta}$ ($\tilde{Q}_{\beta}$)
for (j=1;j<=nobs;j=j+1) {
    for (i=j;i<=nobs;i=i+1) {
        q(i,j,1) = rc (x(i,1), x(j,1)) #
        q(i,j,2) = rc (x(i,2), x(j,2)) #   MAIN EFFECTS TERMS, rc APPENDED AT THE END
        q(i,j,3) = rc (x(i,3), x(j,3)) #
        q(i,j,4) = q(i,j,1) * s(i,3) * s(j,3) #
        q(i,j,5) = s(i,2) * s(j,2) * q(i,j,2) #    x1-x2 INTERACTION TERMS
        q(i,j,6) = q(i,j,1) * q(i,j,2)        #
    }
}

#   START OF REPLICATION
tmp = dble (rnor (nseed))
for (jjj=1;jjj<=nrep;jjj=jjj+1) {

#   GENERATE THE RESPONSE y
for (j=1;j<=nobs;j=j+1)  y(j) = f(j,1) + dble (rnor (0)) * nsize

#   CALCULATE REPLICATE #1 ONLY
if ( jjj != 1 )  next

#   CALL RKPACK DRIVER FOR FITTING THE MODEL
call  dcopy (nobs*nobs*nq, q, 1, qwk, 1)
call  dcopy (nobs*nnull, s, 1, swk, 1)
call  dcopy (nobs, y, 1, ywk, 1)
call  dmudr ('v',_
             swk, nobs, nobs, nnull, qwk, nobs, nobs, nq, ywk,_
             0.d0, init, prec, maxiter,_
             theta, nlaht, score, varht, c, d,_
             dwk, info)
infosv = info

#   SET MARGINAL GRID
for (i=1;i<=ngrid;i=i+1)  xx(i) = 0.d0 + dfloat (i-1) * 1.d0 / dfloat (ngrid-1)

#   GENERATE (\theta R) FOR c_r AND d_r
for (i=1;i<=nobs;i=i+1) {
    for (j=1;j<=ngrid*ngrid;j=j+1) {
        jj = (j - 1) / ngrid + 1   #   j-TH POINT HAS COORDINATES (xx(ii),xx(jj))
        ii = j - (jj-1) * ngrid    #
        r(i,j) = (10.d0**theta(4) * rc (x(i,1), xx(ii)) * (x(i,2) - .5d0) * (xx(jj) - .5d0)_
                + 10.d0**theta(5) * rc (x(i,2), xx(jj)) * (x(i,1) - .5d0) * (xx(ii) - .5d0)_
                + 10.d0**theta(6) * rc (x(i,1), xx(ii)) * rc (x(i,2), xx(jj)))
    }
}

#   MATRIX DECOMPOSITION FOR CALCULATING c_r, d_r, AND sms
for (j=1;j<=nobs;j=j+1)  call  dset (nobs-j+1, 0.d0, qwk(j,j,1), 1)
for (i=1;i<=nq;i=i+1) {
    for (j=1;j<=nobs;j=j+1)
        call  daxpy (nobs-j+1, 10.d0**theta(i), q(j,j,i), 1, qwk(j,j,1), 1)
}
call  dcopy (nobs*nnull, s, 1, swk, 1)
call  dcopy (nobs, y, 1, ywk, 1)
limnla(1) = nlaht - 1.d0
limnla(2) = nlaht + 1.d0
call  dsidr ('v',_
             swk, nobs, nobs, nnull, ywk, qwk(1,1,1), nobs,_
             0.d0, -1, limnla,
             nlaht, score, varht, c, d,_
             qraux, jpvt, dwk,_
             info)
if ( info != 0 )  stop
#   CALCULATE b
b = varht / 10.d0**nlaht

#   CALCULATE c_r, d_r, AND sms
call  dcrdr (swk, nobs, nobs, nnull, qraux, jpvt, qwk(1,1,1), nobs, nlaht,_
             r, nobs, ngrid*ngrid, cr, nobs, dr, nnull, dwk, info)
call  dsms (swk, nobs, nobs, nnull, jpvt, qwk(1,1,1), nobs, nlaht,_
            sms, nnull, dwk, info)

#   GENERATE (\theta R) FOR ESTIMATE EVALUATIONS
for (i=1;i<=nobs;i=i+1) {
    for (j=1;j<=ngrid*ngrid;j=j+1) {
        jj = (j - 1) / ngrid + 1   #   j-TH POINT HAS COORDINATES (xx(ii),xx(jj))
        ii = j - (jj-1) * ngrid    #
        r(i,j) = (10.d0**theta(4) * rc (x(i,1), xx(ii)) * (x(i,2) - .5d0) * (xx(jj) - .5d0)_
                + 10.d0**theta(5) * rc (x(i,2), xx(jj)) * (x(i,1) - .5d0) * (xx(ii) - .5d0)_
                + 10.d0**theta(6) * rc (x(i,1), xx(ii)) * rc (x(i,2), xx(jj)))
    }
}

#   OUTPUT TEST INTERACTION, POSTERIOR MEAN, AND POSTERIOR STANDARD DEVIATION
write (*,*)  'x1	x2	Truth	Estimate	Posterior std'
for (j=1;j<=ngrid*ngrid;j=j+1) {
    jj = (j - 1) / ngrid + 1   #   j-TH POINT HAS COORDINATES (xx(ii),xx(jj))
    ii = j - (jj-1) * ngrid    #
    #   TEST FUNCTION
    dwk(1) = dfi (xx(ii), xx(jj), 1, 2)
    #   POSTERIOR MEAN
    dwk(2) = d(5) * (xx(ii) - .5d0) * (xx(jj) - .5d0)_
            + ddot (nobs, c, 1, r(1,j), 1)
    #   POSTERIOR STANDARD DEVIATION
    dwk(3) = (10.d0**theta(4) * rc (xx(ii), xx(ii)) * (xx(jj) - .5d0) * (xx(jj) - .5d0)_
            + 10.d0**theta(5) * rc (xx(jj), xx(jj)) * (xx(ii) - .5d0) * (xx(ii) - .5d0)_
            + 10.d0**theta(6) * rc (xx(ii), xx(ii)) * rc (xx(jj), xx(jj)))
    dwk(3) = dwk(3) - ddot (nobs, r(1,j), 1, cr(1,j), 1)_
             + sms(5,5) * ((xx(ii) - .5d0) * (xx(jj) - .5d0)) ** 2_
             - 2.d0 * (xx(ii) - .5d0) * (xx(jj) - .5d0) * dr(5,j)
    dwk(3) = dsqrt (b*dwk(3))
    write (*,*)  sngl (xx(ii)), sngl (xx(jj)), (sngl (dwk(i)), i=1,3)
}

}   #   END OF REPLICATION

stop
end


#   TEST MAIN EFFECTS
double precision function  dfm (x, m)
double precision  x
integer           m

switch (m) {
    case 1 :
        dfm = dexp (3.d0 * x) - (dexp (3.d0) - 1.d0) / 3.d0
    case 2 :
        dfm = 1.d6 * (x ** 11 * (1 - x) ** 6) + 1.d4 * (x ** 3 * (1 - x) ** 10) - 6.986477575d0
    default :
        dfm = 0.d0
} 

return
end 


#   TEST INTERACTION
double precision function  dfi (x1, x2, m1, m2)
double precision  x1, x2, pi
integer           m1, m2

pi = 4.d0 * datan (1.d0)
dfi = 0.d0
if ( m1 == 1 & m2 == 2 ) {
    dfi = 5.d0 * dcos (2.d0*pi*(x1-x2))
}

return
end 


#   REPRODUCING KERNEL FOR CUBIC SPLINE ON [0,1]
double precision function  rc (y,x)
double precision  y, x, dk2, dk4

rc = dk2 (y) * dk2 (x) - dk4 (x-y)

return
end


#   AUXILIARY FUNCTION FOR CALCULATING REPRODUCING KERNELS
double precision function  dk2 (x)
double precision  x

x = dabs (x)
dk2 = ( x - .5d0 ) ** 2 
dk2 = ( dk2 - 1.d0 / 12.d0 ) / 2.d0

return
end


#   AUXILIARY FUNCTION FOR CALCULATING REPRODUCING KERNELS
double precision function  dk4 (x)
double precision  x

x = dabs (x)
dk4 = ( x - .5d0 ) ** 2
dk4 = ( dk4 ** 2 - dk4 / 2.d0 + 7.d0 / 240.d0 ) / 24.d0

return
end
