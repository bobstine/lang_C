#   THIS PROGRAM ILLUSTRATES THE USE OF RKPACK ROUTINES IN FITTING A MODEL
#        y = f(x) + e
#   ON E^2 USING THIN-PLATE SPLINES.  THE PROGRAM CALCULATES THE FIT BASED ON
#   IRREGULAR DATA AND EVALUATES THE ESTIMATE ON A REGULAR GRID ON [-2,2]^2.
#   THIS PROGRAM USES THE SEMI-KERNEL WHICH IS EASY TO EVALUATE BUT DOES NOT
#   ALLOW THE CALCULATION OF POSTERIOR VARIANCE.

program  thin

parameter  ( nobs = 100, nnull = 3, ngrid = 31 )

#   PARAMETERS:
#        nobs     number of observations. 
#        nnull    dimension of null space.
#        ngrid    number of marginal grid points on each of the axes

double precision  x(nobs,2), s(nobs,nnull), qraux(nnull), q(nobs,nobs), y(nobs),_
                  nlaht, score, varht, c(nobs), d(nnull), wk(3*nobs), limnla(2),_
                  xx(ngrid), tmp, rt, df, nsize
real              rnor
integer           info, i, j, ii, jj, jpvt(nnull), dseed, nseed, infosv


#   INPUT SIMULATION PARAMETERS
read (*,*) dseed, nseed, nsize    #SEED FOR DESIGN, SEED FOR NOISE, STD OF NOISE
write (*,*) 'Number of observations', nobs
write (*,*) 'Number of grid points', ngrid, 'times', ngrid
write (*,*) 'Seed for uniform design', dseed
write (*,*) 'Seed for Gaussian noise', nseed
write (*,*) 'Standard deviation of noise', sngl (nsize)

#   GENERATE THE DESIGN
tmp = dble (rnor (dseed))
for (j=1;j<=nobs;j=j+1) {
     x(j,1) = dble (rnor (0))
     x(j,2) = dble (rnor (0))
}

#   GENERATE THE MATRIX S
call  dset (nobs, 1.d0, s(1,1), 1)
for (j=1;j<=nobs;j=j+1) {
    s(j,2) = x(j,1)
    s(j,3) = x(j,2)
}

#   GENERATE THE MATRIX K
for (j=1;j<=nobs;j=j+1) {           # rt APPENDED AT THE END
    for (i=j;i<=nobs;i=i+1)  q(i,j) = rt (x(i,1), x(i,2), x(j,1), x(j,2))
}

#   GENERATE THE RESPONSE y
tmp = dble (rnor (nseed))
for (j=1;j<=nobs;j=j+1)  y(j) = df (x(j,1), x(j,2)) + dble (rnor (0)) * nsize

#   CALL RKPACK DRIVER FOR MODEL FITTING
call  dsidr ('v', s, nobs, nobs, nnull, y, q, nobs, 0.d0, 0, limnla,_
             nlaht, score, varht, c, d, qraux, jpvt, wk, info)
infosv = info

#   SET GRID
for (j=1;j<=ngrid;j=j+1)  xx(j) = -2.d0 + 4.d0 * dfloat (j-1) / dfloat (ngrid-1)

#   OUTPUT INFO FROM dsidr, N*LAMBDA, AND SIGMA HAT
write (*,*)  'Info from dsidr =', infosv, 'log10(n lambda) =', sngl (nlaht),_
             'Sigma hat =', sngl (sqrt (varht))
#   OUTPUT TEST FUNCTION AND ESTIMATE ON THE GRID
write (*,*)  'x1	x2	Truth	Estimate'
for (j=1;j<=ngrid*ngrid;j=j+1) {
    jj = (j - 1) / ngrid + 1   #   j-TH POINT HAS COORDINATES (xx(ii),xx(jj))
    ii = j - (jj-1) * ngrid    #
    #   TEST FUNCTION
    wk(1) = df (xx(ii), xx(jj))
    #   ESTIMATE
    wk(2) = d(1) + d(2) * xx(ii) + d(3) * xx(jj)
    for (i=1;i<=nobs;i=i+1)  wk(2) = wk(2) + c(i) * rt (x(i,1), x(i,2), xx(ii), xx(jj))
    write (*,*)  sngl (xx(ii)), sngl (xx(jj)), (sngl (wk(i)), i=1,2)
}

stop
end


#   TEST FUNCTION
double precision function  df (x1, x2)
double precision  x1, x2

df = x1 ** 2 + x2 ** 2
df = 2.d1 * dexp (-df)

return
end 


#   SEMI KERNEL FOR THIN PLATE SPLINE ON E^2 WITH m=2
double precision function  rt (x1, x2, y1, y2)
double precision  x1, x2, y1, y2

rt = (x1 - y1) ** 2 + (x2 - y2) ** 2
if ( rt > 0.d0 )  rt = rt * dlog (rt)

return
end
