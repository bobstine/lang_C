#   THIS PROGRAM ILLUSTRATES THE USE OF RKPACK ROUTINES IN FITTING A MODEL
#        y = C + f1(x1) + f2(x2,x3) + f12(x1,x2,x3) + e
#   ON E^1 x E^2 USING TENSOR-PRODUCT THIN-PLATE SPLINES WITH AVERAGING OPERATOR
#   THE SUMMATION OVER (MARGINAL) DESIGN POINTS.  THE PROGRAM CALCULATES THE FIT
#   AND THE COMPONENT-WISE BAYESIAN CONFIDENCE INTERVALS ON THE DESIGN POINTS,
#   AND COLLECTS COVERAGE PERCENTAGES FOR INTERVALS OF NOMINAL COVERAGES 95%, 90%,
#   75%, AND 50%.  THE SIMULATION RESULTS IN SECTION 7 OF GU AND WAHBA (1992,
#   UW-TR-881-REV) WERE GENERATED USING THIS PROGRAM WITH INTERACTION REMOVED.

program  tptp

parameter  ( nobs = 112, nnull = 6, nq = 5, nrep = 5 )

#   PARAMETERS:
#        nobs     number of observations. 
#        nnull    dimension of null space.
#        nq       number of smoothing parameters.
#        nrep     number of replications.

double precision  x(nobs,3), s1(nobs,2), swk1(nobs,2), qraux1(2), s2(nobs,3),_
                  swk2(nobs,3), qraux2(3), s(nobs,nnull), swk(nobs,nnull),_
                  qraux(nnull), q(nobs,nobs,nq), qwk(nobs,nobs,nq), y(nobs),_
                  ywk(nobs), prec, theta(nq), nlaht, score, varht, c(nobs),_
                  d(nnull), dwk(nobs*nobs*(nq+2)), limnla(2), cr(nobs,nobs,4),_
                  dr(nnull,nobs,4), sms(nnull,nnull), f(nobs,4), nsize, ddot, b, dum
real              rnor
integer           info, i, j, jjj, init, maxiter, jpvt(nnull), infosv, nnull1, nq1,_
                  ct(4,4)


#   SET ALGORITHMIC PARAMETERS
init = 0
prec = 1.d-6
maxiter = 15
nnull1 = nnull
nq1 = nq

#   UNBLOCK THE FOLLOWING SEGMENT FOR MAIN-EFFECT-ONLY MODEL
#nnull1 = 4
#nq1 = 2

#   INPUT DATA
read (*,*)  nsize           # SIZE OF THE NOISE
nsize = dsqrt (nsize)
for (j=1;j<=nobs;j=j+1) {
    read (*,*)  x(j,1), x(j,2), x(j,3), y(j), f(j,1), f(j,2), f(j,3), f(j,4)
}   #   f CONTAINS OVERALL f, MAIN EFFECTS f1, f2, AND INTERACTION f12

#   GENERATE THE MARGINAL SEMI-KERNEL K's
for (j=1;j<=nobs;j=j+1) {
    for (i=j;i<=nobs;i=i+1) {
        q(i,j,1) = dabs (x(i,1)-x(j,1)) ** 3                          # x1 SPACE
        q(i,j,2) = (x(i,2)-x(j,2)) ** 2 + (x(i,3)-x(j,3)) ** 2          # (x2,x3) SPACE
        if ( q(i,j,2) > 0.d0 )  q(i,j,2) = q(i,j,2) * dlog (q(i,j,2))   #
    }
}

#   GENERATE MARGINAL S and Q
#   x1 SPACE
call  dset (nobs, 1.d0, swk1(1,1), 1)                     #                         /R\
call  dcopy (nobs, x(1,1), 1, swk1(1,2), 1)               # QR-DECOM  S~ = (F1 F2) |   |
call  dqrdc (swk1, nobs, nobs, 2, qraux1, jpvt, dwk, 0)   #                         \O/ 
call  dset (nobs*2, 0.d0, s1, 1)                            #
call  dset (2, 1.d0, s1, nobs+1)                            #
for (i=1;i<=2;i=i+1) {                                      # S = F1
    call  dqrsl (swk1, nobs, nobs, 2, qraux1, s1(1,i),_     #
                 s1(1,i), dum, dum, dum, dum, 10000, info)  #
}
call  dqrslm (swk1, nobs, nobs, 2, qraux1, q(1,1,1), nobs, 0, info, dwk)  #
call  dset (nobs*2, 0.d0, q(1,1,1), 1)                                    # Q = F2F2'KF2F2'
call  dqrslm (swk1, nobs, nobs, 2, qraux1, q(1,1,1), nobs, 1, info, dwk)  #
#   (x2,x3) SPACE
call  dset (nobs, 1.d0, swk2(1,1), 1)                     #                         /R\ 
call  dcopy (nobs*2, x(1,2), 1, swk2(1,2), 1)             # QR-DECOM  S~ = (F1 F2) |   |
call  dqrdc (swk2, nobs, nobs, 3, qraux2, jpvt, dwk, 0)   #                         \O/ 
call  dset (nobs*3, 0.d0, s2, 1)                            #
call  dset (3, 1.d0, s2, nobs+1)                            #
for (i=1;i<=3;i=i+1) {                                      # S = F1
    call  dqrsl (swk2, nobs, nobs, 3, qraux2, s2(1,i),_     #
                 s2(1,i), dum, dum, dum, dum, 10000, info)  #
}
call  dqrslm (swk2, nobs, nobs, 3, qraux2, q(1,1,2), nobs, 0, info, dwk)  #                
call  dset (nobs*3, 0.d0, q(1,1,2), 1)					  # Q = F2F2'KF2F2'
call  dqrslm (swk2, nobs, nobs, 3, qraux2, q(1,1,2), nobs, 1, info, dwk)  #

#   GENERATE THE MATRIX S
for (j=1;j<=nobs;j=j+1) {
    s(j,1) = 1.d0                # CONSTANT TERM
    s(j,2) = s1(j,2)               # x1 MAIN EFFECT TERM
    s(j,3) = s2(j,2)                 # (x2,x3) MAIN EFFECT TERMS
    s(j,4) = s2(j,3)                 #
    s(j,5) = s1(j,2) * s2(j,2)         # INTERACTION TERMS
    s(j,6) = s1(j,2) * s2(j,3)         #
}

#   GENERATE THE MATRICES \tilde{Q}_{\beta}'s
for (j=1;j<=nobs;j=j+1) {
    for (i=j;i<=nobs;i=i+1) {
        q(i,j,5) = q(i,j,1) * q(i,j,2)                            #
        q(i,j,3) = q(i,j,1) * (s2(j,2)*s2(i,2)+s2(j,3)*s2(i,3))   # INTERACTION TERMS
        q(i,j,4) = q(i,j,2) * s1(j,2) * s1(i,2)                   #
        q(i,j,1) = q(i,j,1) * s2(j,1) * s2(i,1)                 # x1 MAIN EFFECT TERM
        q(i,j,2) = q(i,j,2) * s1(j,1) * s1(i,1)               # (x2,x3) MAIN EFFECT TERM
    }
}

#   START OF REPLICATION
dum = dble (rnor (5732))
for (jjj=1;jjj<=nrep;jjj=jjj+1) {

#   GENERATE DATA
for (j=1;j<=nobs;j=j+1)  y(j) = f(j,1) + nsize * dble (rnor (0))

#   UNBLOCK NEXT LINE IF ONLY REPLICATE #1 IS OF INTEREST
#if ( jjj != 1 )  next

#   CALL RKPACK DRIVER FOR MODEL FITTING
call  dcopy (nobs*nobs*nq, q, 1, qwk, 1)
call  dcopy (nobs*nnull, s, 1, swk, 1)
call  dcopy (nobs, y, 1, ywk, 1)
call  dmudr ('v',_
             swk, nobs, nobs, nnull1, qwk, nobs, nobs, nq1, ywk,_
             0.d0, init, prec, maxiter,_
             theta, nlaht, score, varht, c, d,_
             dwk, info)
infosv = info

#   GENERATE (\theta R)'s IN qwk FOR CALCULATING c_r AND d_r
for (j=1;j<=nobs;j=j+1)  call  dset (nobs-j+1, 0.d0, qwk(j,j,1), 1)
#   (\theta R) FOR OVERALL FUNCTION
for (i=1;i<=nq1;i=i+1) {
    for (j=1;j<=nobs;j=j+1)
        call  daxpy (nobs-j+1, 10.d0**theta(i), q(j,j,i), 1, qwk(j,j,1), 1)
}
#   (\theta R)'s FOR THE MAIN EFFECTS
for (i=1;i<=2;i=i+1) {
    for (j=1;j<=nobs;j=j+1) {
        call  dcopy (nobs-j+1, q(j,j,i), 1, qwk(j,j,i+1), 1)
        call  dscal (nobs-j+1, 10.d0**theta(i), qwk(j,j,i+1), 1)
    }
}
#   (\theta R) FOR THE INTERACTION
for (j=1;j<=nobs;j=j+1) {
    call  dset (nobs-j+1, 0.d0, qwk(j,j,4), 1)
    for (i=3;i<=5;i=i+1)
        call  daxpy (nobs-j+1, 10.d0**theta(i), q(j,j,i), 1, qwk(j,j,4), 1)
}
#   FILL THE UPPER TRIANGLES
for (i=1;i<=4;i=i+1) {
    for (j=1;j<=nobs;j=j+1)
        call  dcopy (nobs-j, qwk(j+1,j,i), 1, qwk(j,j+1,i), nobs)
}

#   MATRIX DECOMPOSITION FOR CALCULATING c_r, d_r, AND sms
for (j=1;j<=nobs;j=j+1)  call  dcopy (nobs-j+1, qwk(j,j,1), 1, qwk(j,j,5), 1)
call  dcopy (nobs*nnull, s, 1, swk, 1)
call  dcopy (nobs, y, 1, ywk, 1)
limnla(1) = nlaht - 1.d0
limnla(2) = nlaht + 1.d0
call  dsidr ('v',_
             swk, nobs, nobs, nnull1, ywk, qwk(1,1,5), nobs,_
             0.d0, -1, limnla,_
             nlaht, score, varht, c, d,_
             qraux, jpvt, dwk,_
             info)
if ( info != 0 )  stop
#   CALCULATE b
b = varht / 10.d0**nlaht

#   CALCULATE c_r, d_r, AND sms
for (i=1;i<=4;i=i+1) {
    call  dcrdr (swk, nobs, nobs, nnull1, qraux, jpvt, qwk(1,1,5), nobs, nlaht,_
                 qwk(1,1,i), nobs, nobs, cr(1,1,i), nobs, dr(1,1,i), nnull,_
                 dwk, info)
}
call  dsms (swk, nobs, nobs, nnull1, jpvt, qwk(1,1,5), nobs, nlaht,_
            sms, nnull, dwk, info)

#   GENERATE (\theta R)'s IN qwk FOR ESTIMATE EVALUATIONS
for (j=1;j<=nobs;j=j+1)  call  dset (nobs-j+1, 0.d0, qwk(j,j,1), 1)
#   (\theta R) FOR OVERALL FUNCTION
for (i=1;i<=nq1;i=i+1) {
    for (j=1;j<=nobs;j=j+1)
        call  daxpy (nobs-j+1, 10.d0**theta(i), q(j,j,i), 1, qwk(j,j,1), 1)
}
#   (\theta R)'s FOR THE MAIN EFFECTS
for (i=1;i<=2;i=i+1) {
    for (j=1;j<=nobs;j=j+1) {
        call  dcopy (nobs-j+1, q(j,j,i), 1, qwk(j,j,i+1), 1)
        call  dscal (nobs-j+1, 10.d0**theta(i), qwk(j,j,i+1), 1)
    }
}
#   (\theta R) FOR THE INTERACTION
for (j=1;j<=nobs;j=j+1) {
    call  dset (nobs-j+1, 0.d0, qwk(j,j,4), 1)
    for (i=3;i<=5;i=i+1)
        call  daxpy (nobs-j+1, 10.d0**theta(i), q(j,j,i), 1, qwk(j,j,4), 1)
}
#   FILL THE UPPER TRIANGLES
for (i=1;i<=4;i=i+1) {
    for (j=1;j<=nobs;j=j+1)
        call  dcopy (nobs-j, qwk(j+1,j,i), 1, qwk(j,j+1,i), nobs)
}

#   COLLECTING COVERAGE INFORMATION ON THE DESIGN POINTS
for (i=1;i<=4;i=i+1)
    for (j=1;j<=4;j=j+1)  ct(i,j) = 0
for (j=1;j<=nobs;j=j+1) {
    #   OVERALL ESTIMATE:  POSTERIOR MEAN
    dwk(1) = y(j) - 10.d0**nlaht * c(j)
    #   OVERALL ESTIMATE:  POSTERIOR STANDARD DEVIATION
    call  dsymv ('u', nnull1, 1.d0, sms, nnull, s(j,1), nobs, 0.d0, ywk, 1)
    dwk(2) = (qwk(j,j,1) - ddot (nobs, qwk(1,j,1), 1, cr(1,j,1), 1))_
            + ddot (nnull1, s(j,1), nobs, ywk, 1)_
            - 2.d0 * ddot (nnull1, s(j,1), nobs, dr(1,j,1), 1)
    dwk(2) = dsqrt (b*dwk(2))
    #   OVERALL ESTIMATE:  COVERAGE (NO. OF POINTS OUT)
    if ( dabs (f(j,1)-dwk(1)) > dwk(2)*1.9604d0 )  ct(1,1) = ct(1,1) + 1  # 95%
    if ( dabs (f(j,1)-dwk(1)) > dwk(2)*1.6452d0 )  ct(1,2) = ct(1,2) + 1  # 90%
    if ( dabs (f(j,1)-dwk(1)) > dwk(2)*1.1504d0 )  ct(1,3) = ct(1,3) + 1  # 75%
    if ( dabs (f(j,1)-dwk(1)) > dwk(2)*0.6742d0 )  ct(1,4) = ct(1,4) + 1  # 50%

    #   x1 MAIN EFFECT:  POSTERIOR MEAN
    dwk(3) = s(j,2) * d(2) + ddot (nobs, qwk(1,j,2), 1, c, 1)
    #   x1 MAIN EFFECT:  POSTERIOR STANDARD DEVIATION
    dwk(4) = (qwk(j,j,2) - ddot (nobs, qwk(1,j,2), 1, cr(1,j,2), 1))_
            + s(j,2) * s(j,2) * sms(2,2) - 2.d0 * s(j,2) * dr(2,j,2)
    dwk(4) = dsqrt (b*dwk(4))
    #   x1 MAIN EFFECT:  COVERAGE (NO. OF POINTS OUT)
    if ( dabs (f(j,2)-dwk(3)) > dwk(4)*1.9604d0 )  ct(2,1) = ct(2,1) + 1  # 95%
    if ( dabs (f(j,2)-dwk(3)) > dwk(4)*1.6452d0 )  ct(2,2) = ct(2,2) + 1  # 90%
    if ( dabs (f(j,2)-dwk(3)) > dwk(4)*1.1504d0 )  ct(2,3) = ct(2,3) + 1  # 75%
    if ( dabs (f(j,2)-dwk(3)) > dwk(4)*0.6742d0 )  ct(2,4) = ct(2,4) + 1  # 50%

    #   (x2,x3) MAIN EFFECT:  POSTERIOR MEAN
    dwk(5) = s(j,3) * d(3) + s(j,4) * d(4) + ddot (nobs, qwk(1,j,3), 1, c, 1)
    #   (x2,x3) MAIN EFFECT:  POSTERIOR STANDARD DEVIATION
    dwk(6) = (qwk(j,j,3) - ddot (nobs, qwk(1,j,3), 1, cr(1,j,3), 1))_
            + (s(j,3) * s(j,3) * sms(3,3) + s(j,4) * s(j,4) * sms(4,4)_
               + 2.d0 * s(j,3) * s(j,4) * sms(3,4))_
            - 2.d0 * (s(j,3) * dr(3,j,3) + s(j,4) * dr(4,j,3))
    dwk(6) = dsqrt (b*dwk(6))
    #   (x2,x3) MAIN EFFECT:  COVERAGE (NO. OF POINTS OUT)
    if ( dabs (f(j,3)-dwk(5)) > dwk(6)*1.9604d0 )  ct(3,1) = ct(3,1) + 1  # 95%
    if ( dabs (f(j,3)-dwk(5)) > dwk(6)*1.6452d0 )  ct(3,2) = ct(3,2) + 1  # 90%
    if ( dabs (f(j,3)-dwk(5)) > dwk(6)*1.1504d0 )  ct(3,3) = ct(3,3) + 1  # 75%
    if ( dabs (f(j,3)-dwk(5)) > dwk(6)*0.6742d0 )  ct(3,4) = ct(3,4) + 1  # 50%

    #   INTERACTION:  POSTERIOR MEAN
    dwk(7) = s(j,5) * d(5) + s(j,6) * d(6) + ddot (nobs, qwk(1,j,4), 1, c, 1)
    #   INTERACTION:  POSTERIOR STANDARD DEVIATION
    dwk(8) = (qwk(j,j,4) - ddot (nobs, qwk(1,j,4), 1, cr(1,j,4), 1))_
            + (s(j,5) * s(j,5) * sms(5,5) + s(j,6) * s(j,6) * sms(6,6)_
               + 2.d0 * s(j,5) * s(j,6) * sms(5,6))_
            - 2.d0 * (s(j,5) * dr(5,j,4) + s(j,6) * dr(6,j,4))
    dwk(8) = dsqrt (b*dwk(8))
    #   INTERACTION:  COVERAGE (NO. OF POINTS OUT)
    if ( dabs (f(j,4)-dwk(7)) > dwk(8)*1.9604d0 )  ct(4,1) = ct(4,1) + 1  # 95%
    if ( dabs (f(j,4)-dwk(7)) > dwk(8)*1.6452d0 )  ct(4,2) = ct(4,2) + 1  # 90%
    if ( dabs (f(j,4)-dwk(7)) > dwk(8)*1.1504d0 )  ct(4,3) = ct(4,3) + 1  # 75%
    if ( dabs (f(j,4)-dwk(7)) > dwk(8)*0.6742d0 )  ct(4,4) = ct(4,4) + 1  # 50%

#   UNBLOCK THE FOLLOWING SEGMENT TO OUTPUT MARGINAL DESIGNS, RESPONSE y, 
#   POSTERIOR MEANS, AND POSTERIOR STANDARD DEVIATIONS
#    write (*,*)  (sngl (x(j,i)),i=1,3),_    #   marginal designs
#                 sngl (y(j)),_              #   response
#                 (sngl (dwk(i*2-1)),i=1,4),_#   posterior means
#                 (sngl (dwk(i*2)),i=1,4)    #   posterior stds
#    write (*,*)

}

#   OUTPUT COVERAGE INFORMATION, VAR ESTIMATE, AND ERROR CHECK (from dmudr)
                                                     # NO. OF UNCOVERED DATA POINTS
for (j=1;j<=4;j=j+1)  write (*,*)  (ct(i,j), i=1,4)  # ROWS:    95%, 90%, 75%, 50%
                                                     # COLUMNS: f, f1, f2, f12
write (*,*)  sngl (varht), infosv   # SIGMA HAT, info FROM dmudr

}   #   END OF REPLICATION

stop
end
