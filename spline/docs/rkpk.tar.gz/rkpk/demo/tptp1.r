#   THIS PROGRAM ILLUSTRATES THE USE OF RKPACK ROUTINES IN FITTING A MODEL
#        y = C + f1(x1) + f2(x2,x3) + f12(x1,x2,x3) + e
#   ON E^1 x E^2 USING TENSOR-PRODUCT THIN-PLATE SPLINES WITH AVERAGING OPERATOR
#   THE SUMMATION OVER (MARGINAL) DESIGN POINTS.  THE PROGRAM CALCULATES THE FIT
#   BASED ON IRREGULAR DATA AND EVALUATES THE ESTIMATE AND THE COMPONENT-WISE
#   BAYESIAN CONFIDENCE INTERVALS OF THE (x2,x3) MAIN EFFECT ON REGULAR GRIDS.
#   THE PLOTS IN SECTION 7 OF GU AND WAHBA (1992, UW-TR-881-REV) WERE BASED ON
#   DATA GENERATED USING THIS PROGRAM WITH INTERACTION REMOVED.

program  tptp1

parameter  ( nobs = 112, nnull = 6, nq = 5, ngrid = 41 )

#   PARAMETERS:
#        nobs     number of observations. 
#        nnull    dimension of null space.
#        nq       number of smoothing parameters.
#        ngrid    number of grid points on each margin of (x2,x3) plane.

double precision  x(nobs,3), s1(nobs,2), swk1(nobs,2), qraux1(2), s2(nobs,3),_
                  swk2(nobs,3), qraux2(3), s(nobs,nnull), swk(nobs,nnull),_
                  qraux(nnull), q(nobs,nobs,nq), qwk(nobs,nobs,nq), y(nobs),_
                  ywk(nobs), prec, theta(nq), nlaht, score, varht, c(nobs),_
                  d(nnull), dwk(nobs*nobs*(nq+2)), limnla(2), xx(ngrid),_
                  r(nobs,ngrid*ngrid), cr(nobs,ngrid*ngrid), dr(nnull,ngrid*ngrid),_
                  sms(nnull,nnull), ddot, b, dum
integer           info, i, j, ii, jj, init, maxiter, jpvt(nnull), infosv, nnull1, nq1


#   SET ALGORITHMIC PARAMETERS
init = 0
prec = 1.d-6
maxiter = 15
nnull1 = nnull
nq1 = nq

#   UNBLOCK THE FOLLOWING SEGMENT FOR MAIN-EFFECT-ONLY MODEL
#nnull1 = 4
#nq1 = 2

#   INPUT DATA
read (*,*)  dum
for (j=1;j<=nobs;j=j+1) {
    read (*,*)  x(j,1), x(j,2), x(j,3), y(j), dum, dum, dum, dum
}

#   GENERATE THE MARGINAL SEMI-KERNEL K's
for (j=1;j<=nobs;j=j+1) {
    for (i=j;i<=nobs;i=i+1) {
        q(i,j,1) = dabs (x(i,1)-x(j,1)) ** 3                          # x1 SPACE
        q(i,j,2) = (x(i,2)-x(j,2)) ** 2 + (x(i,3)-x(j,3)) ** 2          # (x2,x3) SPACE
        if ( q(i,j,2) > 0.d0 )  q(i,j,2) = q(i,j,2) * dlog (q(i,j,2))   #
    }
}

#   GENERATE MARGINAL S and Q
#   x1 SPACE
call  dset (nobs, 1.d0, swk1(1,1), 1)                     #                         /R\ 
call  dcopy (nobs, x(1,1), 1, swk1(1,2), 1)               # QR-DECOM  S~ = (F1 F2) |   |
call  dqrdc (swk1, nobs, nobs, 2, qraux1, jpvt, dwk, 0)   #                         \O/ 
call  dset (nobs*2, 0.d0, s1, 1)                            #
call  dset (2, 1.d0, s1, nobs+1)                            #
for (i=1;i<=2;i=i+1) {                                      # S = F1
    call  dqrsl (swk1, nobs, nobs, 2, qraux1, s1(1,i),_     #
                 s1(1,i), dum, dum, dum, dum, 10000, info)  #
}
call  dqrslm (swk1, nobs, nobs, 2, qraux1, q(1,1,1), nobs, 0, info, dwk)  #
call  dset (nobs*2, 0.d0, q(1,1,1), 1)                                    # Q = F2F2'KF2F2'
call  dqrslm (swk1, nobs, nobs, 2, qraux1, q(1,1,1), nobs, 1, info, dwk)  #
#   (x2,x3) SPACE
call  dset (nobs, 1.d0, swk2(1,1), 1)                     #                         /R\ 
call  dcopy (nobs*2, x(1,2), 1, swk2(1,2), 1)             # QR-DECOM  S~ = (F1 F2) |   |
call  dqrdc (swk2, nobs, nobs, 3, qraux2, jpvt, dwk, 0)   #                         \O/ 
call  dset (nobs*3, 0.d0, s2, 1)                            #
call  dset (3, 1.d0, s2, nobs+1)                            #
for (i=1;i<=3;i=i+1) {                                      # S = F1
    call  dqrsl (swk2, nobs, nobs, 3, qraux2, s2(1,i),_     #
                 s2(1,i), dum, dum, dum, dum, 10000, info)  #
}
call  dqrslm (swk2, nobs, nobs, 3, qraux2, q(1,1,2), nobs, 0, info, dwk)  #                
call  dset (nobs*3, 0.d0, q(1,1,2), 1)					  # Q = F2F2'KF2F2'
call  dqrslm (swk2, nobs, nobs, 3, qraux2, q(1,1,2), nobs, 1, info, dwk)  #

#   GENERATE THE MATRIX S
for (j=1;j<=nobs;j=j+1) {
    s(j,1) = 1.d0                  # CONSTANT TERM
    s(j,2) = s1(j,2)                 # x1 MAIN EFFECT TERM
    s(j,3) = s2(j,2)                 # (x2,x3) MAIN EFFECT TERMS
    s(j,4) = s2(j,3)                 #
    s(j,5) = s1(j,2) * s2(j,2)         # INTERACTION TERMS
    s(j,6) = s1(j,2) * s2(j,3)         #
}

#   GENERATE THE MATRICES \tilde{Q}_{\beta}'s
for (j=1;j<=nobs;j=j+1) {
    for (i=j;i<=nobs;i=i+1) {
        q(i,j,5) = q(i,j,1) * q(i,j,2)                            #
        q(i,j,3) = q(i,j,1) * (s2(j,2)*s2(i,2)+s2(j,3)*s2(i,3))   # INTERACTION TERMS
        q(i,j,4) = q(i,j,2) * s1(j,2) * s1(i,2)                   #
        q(i,j,1) = q(i,j,1) * s2(j,1) * s2(i,1)                 # x1 MAIN EFFECT TERM
        q(i,j,2) = q(i,j,2) * s1(j,1) * s1(i,1)               # (x2,x3) MAIN EFFECT TERM
    }
}

#   CALL RKPACK DRIVER FOR MODEL FITTING
call  dcopy (nobs*nobs*nq, q, 1, qwk, 1)
call  dcopy (nobs*nnull, s, 1, swk, 1)
call  dcopy (nobs, y, 1, ywk, 1)
call  dmudr ('v',_
             swk, nobs, nobs, nnull1, qwk, nobs, nobs, nq1, ywk,_
             0.d0, init, prec, maxiter,_
             theta, nlaht, score, varht, c, d,_
             dwk, info)
infosv = info

#   SET MARGINAL GRID
for (i=1;i<=ngrid;i=i+1)  xx(i) = -.04d0 + dfloat (i-1) * .08d0 / dfloat (ngrid-1)

#   K S~ R^{-1} R^{-T} = KSR^{-T}
for (j=1;j<=nobs;j=j+1) {
    for (i=j;i<=nobs;i=i+1) {                                                 #
        qwk(i,j,2) = (x(i,2)-x(j,2)) ** 2 + (x(i,3)-x(j,3)) ** 2              # K IN qwk(,,2)
        if ( qwk(i,j,2) > 0.d0 )  qwk(i,j,2) = qwk(i,j,2) * dlog (qwk(i,j,2)) #
    }
}
for (i=1;i<=3;i=i+1) {                                #
    call  dsymv ('l', nobs, 1.d0, qwk(1,1,2), nobs,_  #
                 s2(1,i), 1, 0.d0, qwk(1,i,3), 1)     # 
}                                                     # KSR^{-T} in qwk(,1:3,3)
for (j=1;j<=nobs;j=j+1) {                             #
    call  dcopy (3, qwk(j,1,3), nobs, dwk, 1)         #
    call  dtrsl (swk2, nobs, 3, dwk, 01, info)        #
    call  dcopy (3, dwk, 1, qwk(j,1,3), nobs)         #
}

#   GENERATE (\theta R) FOR CALCULATING c_r AND d_r
for (j=1;j<=ngrid*ngrid;j=j+1) {
    jj = (j - 1) / ngrid + 1   #   j-TH POINT u HAS COORDINATES (xx(ii),xx(jj))
    ii = j - (jj-1) * ngrid    #
    for (i=1;i<=nobs;i=i+1) {
        r(i,j) = (x(i,2)-xx(ii)) ** 2 + (x(i,3)-xx(jj)) ** 2          #       
        if ( r(i,j) > 0.d0 )  r(i,j) = r(i,j) * dlog (r(i,j))         #       
        r(i,j) = r(i,j) - (qwk(i,1,3)_			              #
                 + qwk(i,2,3) * xx(ii) + qwk(i,3,3) * xx(jj))         # R(t,u) IN r(,j) 
    }                                                                 #
    call  dqrsl (swk2, nobs, nobs, 3, qraux2, r(1,j), dum, r(1,j),_   #
                 dum, r(1,j), dum, 00010, info)                       #
    call  dscal (nobs, s1(1,1)*s1(1,1)*10.d0**theta(2), r(1,j), 1)    #
}

#   MATRIX DECOMPOSITION FOR CALCULATING c_r, d_r, AND sms
for (j=1;j<=nobs;j=j+1)  call  dset (nobs-j+1, 0.d0, qwk(j,j,1), 1)
for (i=1;i<=nq1;i=i+1) {
    for (j=1;j<=nobs;j=j+1)
        call  daxpy (nobs-j+1, 10.d0**theta(i), q(j,j,i), 1, qwk(j,j,1), 1)
}
call  dcopy (nobs*nnull, s, 1, swk, 1)
call  dcopy (nobs, y, 1, ywk, 1)
limnla(1) = nlaht - 1.d0
limnla(2) = nlaht + 1.d0
call  dsidr ('v',_
             swk, nobs, nobs, nnull1, ywk, qwk(1,1,1), nobs,_
             0.d0, -1, limnla,_
             nlaht, score, varht, c, d,_
             qraux, jpvt, dwk,_
             info)
if ( info != 0 )  stop

#   CALCULATE b
b = varht / 10.d0**nlaht

#   CALCULATE c_r, d_r, AND sms
call  dcrdr (swk, nobs, nobs, nnull1, qraux, jpvt, qwk(1,1,1), nobs, nlaht,_
             r, nobs, ngrid*ngrid, cr, nobs, dr, nnull, dwk, info)
call  dsms (swk, nobs, nobs, nnull1, jpvt, qwk(1,1,1), nobs, nlaht,_
            sms, nnull, dwk, info)

#   CALCULATE POSTERIOR MEAN AND STANDARD DEVIATION ON GRID
write (*,*)  'x2	x3	Estimate	Posterior std'
call  dqrslm (swk2, nobs, nobs, 3, qraux2, qwk(1,1,2), nobs, 0, info, dwk)   # FKF'
for (j=1;j<=ngrid*ngrid;j=j+1) {
    jj = (j - 1) / ngrid + 1    # j-TH POINT u HAS COORDINATES (xx(ii),xx(jj))
    ii = j - (jj-1) * ngrid     #
    dwk(1) = 1.d0                                  #
    dwk(2) = xx(ii)                                # NULL SPACE BASIS \phi IN dwk(1:3)
    dwk(3) = xx(jj)                                #
    call  dtrsl (swk2, nobs, 3, dwk, 11, info)     #
    call  dsymv ('l', 3, 1.d0, qwk(1,1,2), nobs,_    #
                 dwk, 1, 0.d0, dwk(4), 1)            # SKS'\phi IN dwk(4:6)
    for (i=1;i<=nobs;i=i+1) {                                         #
        r(i,j) = (x(i,2)-xx(ii)) ** 2 + (x(i,3)-xx(jj)) ** 2          # K_{t,u} in r(,j)
        if ( r(i,j) > 0.d0 )  r(i,j) = r(i,j) * dlog (r(i,j))         #
    }
    for (i=1;i<=3;i=i+1)
        dwk(i+6) = ddot (nobs, r(1,j), 1, s2(1,i), 1)                 # K_{u,t}S IN dwk(7:9)
    for (i=1;i<=nobs;i=i+1) {
        r(i,j) = r(i,j) - (qwk(i,1,3)_                                #
                + qwk(i,2,3) * xx(ii) + qwk(i,3,3) * xx(jj))          #
    }                                                                 # R(t,u) IN r(,j)
    call  dqrsl (swk2, nobs, nobs, 3, qraux2, r(1,j), dum, r(1,j),_   #
                 dum, r(1,j), dum, 00010, info)                       #
    #   SCALING
    call  dscal (6, 10.d0**theta(2)*s1(1,1)*s1(1,1), dwk(4), 1)
    call  dscal (nobs, s1(1,1)*s1(1,1)*10.d0**theta(2), r(1,j), 1)
    #   POSTERIOR MEAN
    dwk(10) = dwk(2) * d(3) + dwk(3) * d(4) + ddot (nobs, r(1,j), 1, c, 1)
    #   POSTERIOR STANDARD DEVIATION
    dwk(11) = ddot (3, dwk, 1, dwk(4), 1) - 2.d0 * ddot (3, dwk, 1, dwk(7), 1)
    dwk(11) = (dwk(11) - ddot (nobs, r(1,j), 1, cr(1,j), 1))_
             + (dwk(2) * dwk(2) * sms(3,3) + dwk(3) * dwk(3) * sms(4,4)_
                + 2.d0 * dwk(2) * dwk(3) * sms(3,4))_
             - 2.d0 * (dwk(2) * dr(3,j) + dwk(3) * dr(4,j))
    dwk(11) = dsqrt (b*dwk(11))
    write (*,*)  sngl (xx(ii)), sngl (xx(jj)), sngl (dwk(10)), sngl (dwk(11))
}

stop
end
