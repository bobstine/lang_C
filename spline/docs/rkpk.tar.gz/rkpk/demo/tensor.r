#   THIS PROGRAM ILLUSTRATES THE USE OF RKPACK ROUTINES IN FITTING A MODEL
#        y = C + f1(x1) + f2(x2) + f3(x3) + f12(x1,x2) + e
#   ON [0,1]^3 USING TENSOR PRODUCT SPLINES WITH CUBIC SPLINE SPACE AS MARGINALS
#   AND WITH INTEGRATION SIDE CONDITIONS.  THE PROGRAM CALCULATES THE FIT AND THE
#   COMPONENT-WISE BAYESIAN CONFIDENCE INTERVALS ON THE DESIGN POINTS, AND COLLECTS
#   COVERAGE PERCENTAGES FOR INTERVALS OF NOMINAL COVERAGES 95%, 90%, 75%, AND 50%.
#   THE RESULTS IN SECTION 6 OF GU AND WAHBA (1992, UW-TR-881-REV) WERE GENERATED
#   USING THIS PROGRAM.

program  tensor

#   CAUTION:  nobs=200 TAKES A LOT OF MEMORY.
parameter  ( nobs = 100, nnull = 5, nq = 6, k = 3, nrep = 5 )

#   PARAMETERS:
#        nobs     number of observations. 
#        nnull    dimension of null space.
#        nq       number of smoothing parameters.
#        k        number of variables.
#        nrep     number of replicates requested.

double precision  x(nobs,k), s(nobs,nnull), swk(nobs,nnull), q(nobs,nobs,nq),_
                  qwk(nobs,nobs,nq), y(nobs), ywk(nobs), prec, theta(nq), nlaht,_
                  score, varht, b, c(nobs), d(nnull), dwk(nobs*nobs*(nq+2)),_
                  cr(nobs,nobs,nnull), dr(nnull,nobs,nnull), qraux(nnull),_
                  sms(nnull,nnull), limnla(2), tmp, rc, dfm, dfi, ddot,_
                  f(nobs,nnull), nsize
real              uni, rnor
integer           info, i, j, jjj, init, maxiter, jpvt(nnull), ct(5,4), dseed, nseed, infosv


#   SET ALGORITHMIC PARAMETERS
init = 0
prec = 1.d-6
maxiter = 30

#   INPUT SIMULATION PARAMETERS
read (*,*) dseed, nseed, nsize    #SEED FOR DESIGN, SEED FOR NOISE, STD OF NOISE
write (*,*) 'Number of observations', nobs
write (*,*) 'Seed for uniform design', dseed   # 2375 WAS USED IN THE SIMULATIONS
write (*,*) 'Seed for Gaussian noise', nseed   # 5732 WAS USED IN THE SIMULATIONS
write (*,*) 'Standard deviation of noise', sngl (nsize)   # 1, 3, AND 10 USED IN SIMULATIONS

#   GENERATE THE DESIGN
tmp = dble (uni (dseed))
for (j=1;j<=nobs;j=j+1) {
    for (i=1;i<=k;i=i+1)  x(j,i) = dble (uni (0))
}

#   GENERATE THE TEST FUNCTION
for (j=1;j<=nobs;j=j+1) {
    f(j,2) = dfm (x(j,1), 1)   # dfm AND dfi ARE APPENDED AT THE END OF THIS PROGRAM
    f(j,3) = dfm (x(j,2), 2)
    f(j,4) = dfm (x(j,3), 3)
    f(j,5) = dfi (x(j,1), x(j,2), 1, 2)
    f(j,1) = 1.d0 + f(j,2) + f(j,3) + f(j,4) + f(j,5)
}

#   GENERATE THE MATRIX S
call  dset (nobs, 1.d0, s(1,1), 1)
for (j=1;j<=nobs;j=j+1) {
    s(j,2) = x(j,1) - .5d0   #
    s(j,3) = x(j,2) - .5d0   #   MAIN EFFECTS TERMS
    s(j,4) = x(j,3) - .5d0   #
    s(j,5) = s(j,2) * s(j,3)   #   x1-x2 INTERACTION TERM
}

#   GENERATE THE MATRICES $\tilde{\Sigma}_{\beta}$ ($\tilde{Q}_{\beta}$)
for (j=1;j<=nobs;j=j+1) {
    for (i=j;i<=nobs;i=i+1) {
        q(i,j,1) = rc (x(i,1), x(j,1)) #
        q(i,j,2) = rc (x(i,2), x(j,2)) #   MAIN EFFECTS TERMS, rc APPENDED AT THE END
        q(i,j,3) = rc (x(i,3), x(j,3)) #
        q(i,j,4) = q(i,j,1) * s(i,3) * s(j,3) #
        q(i,j,5) = s(i,2) * s(j,2) * q(i,j,2) #   x1-x2 INTERACTION TERMS
        q(i,j,6) = q(i,j,1) * q(i,j,2)        #
    }
}

#   START OF REPLICATION
tmp = dble (rnor (nseed))
for (jjj=1;jjj<=nrep;jjj=jjj+1) {

#   GENERATE THE RESPONSE y
for (j=1;j<=nobs;j=j+1)  y(j) = f(j,1) + dble (rnor (0)) * nsize

#   UNBLOCK NEXT LINE IF ONLY REPLICATE #1 IS OF INTEREST
#if ( jjj != 1 )  next

#   CALL RKPACK DRIVER FOR MODEL FITTING
call  dcopy (nobs*nobs*nq, q, 1, qwk, 1)
call  dcopy (nobs*nnull, s, 1, swk, 1)
call  dcopy (nobs, y, 1, ywk, 1)
call  dmudr ('v',_
             swk, nobs, nobs, nnull, qwk, nobs, nobs, nq, ywk,_
             0.d0, init, prec, maxiter,_
             theta, nlaht, score, varht, c, d,_
             dwk, info)
infosv = info

#   GENERATE (\theta R)'s IN qwk FOR CALCULATING c_r AND d_r
for (j=1;j<=nobs;j=j+1)  call  dset (nobs-j+1, 0.d0, qwk(j,j,1), 1)
#   (\theta R) FOR OVERALL FUNCTION
for (i=1;i<=nq;i=i+1) {
    for (j=1;j<=nobs;j=j+1)
        call  daxpy (nobs-j+1, 10.d0**theta(i), q(j,j,i), 1, qwk(j,j,1), 1)
}
#   (\theta R)'s FOR THE MAIN EFFECTS
for (i=1;i<=3;i=i+1) {
    for (j=1;j<=nobs;j=j+1) {
        call  dcopy (nobs-j+1, q(j,j,i), 1, qwk(j,j,i+1), 1)
        call  dscal (nobs-j+1, 10.d0**theta(i), qwk(j,j,i+1), 1)
    }
}
#   (\theta R) FOR THE INTERACTION
for (j=1;j<=nobs;j=j+1) {
    call  dset (nobs-j+1, 0.d0, qwk(j,j,5), 1)
    for (i=4;i<=6;i=i+1)
        call  daxpy (nobs-j+1, 10.d0**theta(i), q(j,j,i), 1, qwk(j,j,5), 1)
}
#   FILL THE UPPER TRIANGLES
for (i=1;i<=5;i=i+1) {
    for (j=1;j<=nobs;j=j+1)
        call  dcopy (nobs-j, qwk(j+1,j,i), 1, qwk(j,j+1,i), nobs)
}

#   MATRIX DECOMPOSITION FOR CALCULATING c_r, d_r, AND sms
for (j=1;j<=nobs;j=j+1)  call  dcopy (nobs-j+1, qwk(j,j,1), 1, qwk(j,j,6), 1)
call  dcopy (nobs*nnull, s, 1, swk, 1)
call  dcopy (nobs, y, 1, ywk, 1)
limnla(1) = nlaht - 1.d0
limnla(2) = nlaht + 1.d0
call  dsidr ('v',_
             swk, nobs, nobs, nnull, ywk, qwk(1,1,6), nobs,_
             0.d0, -1, limnla,_
             nlaht, score, varht, c, d,_
             qraux, jpvt, dwk,_
             info)
if ( info != 0 )  stop
#   CALCULATE b
b = varht / 10.d0**nlaht

#   CALCULATE c_r, d_r, AND sms
for (i=1;i<=5;i=i+1) {
    call  dcrdr (swk, nobs, nobs, nnull, qraux, jpvt, qwk(1,1,6), nobs, nlaht,_
                 qwk(1,1,i), nobs, nobs, cr(1,1,i), nobs, dr(1,1,i), nnull,_
                 dwk, info)
}
call  dsms (swk, nobs, nobs, nnull, jpvt, qwk(1,1,6), nobs, nlaht,_
            sms, nnull, dwk, info)

#   GENERATE (\theta R)'s IN qwk FOR ESTIMATE EVALUATIONS
for (j=1;j<=nobs;j=j+1)  call  dset (nobs-j+1, 0.d0, qwk(j,j,1), 1)
#   (\theta R) FOR THE OVERALL FUNCTION
for (i=1;i<=nq;i=i+1) {
    for (j=1;j<=nobs;j=j+1)
        call  daxpy (nobs-j+1, 10.d0**theta(i), q(j,j,i), 1, qwk(j,j,1), 1)
}
#   (\theta R)'s FOR THE MAIN EFFECTS TERMS
for (i=1;i<=3;i=i+1) {
    for (j=1;j<=nobs;j=j+1) {
        call  dcopy (nobs-j+1, q(j,j,i), 1, qwk(j,j,i+1), 1)
        call  dscal (nobs-j+1, 10.d0**theta(i), qwk(j,j,i+1), 1)
    }
}
#   (\theta R) FOR THE COMBINED INTERACTION TERM
for (j=1;j<=nobs;j=j+1) {
    call  dset (nobs-j+1, 0.d0, qwk(j,j,5), 1)
    for (i=4;i<=6;i=i+1)
        call  daxpy (nobs-j+1, 10.d0**theta(i), q(j,j,i), 1, qwk(j,j,5), 1)
}
#   FILL THE UPPER TRIANGLES
for (i=1;i<=5;i=i+1) {
    for (j=1;j<=nobs;j=j+1)
        call  dcopy (nobs-j, qwk(j+1,j,i), 1, qwk(j,j+1,i), nobs)
}

#   COLLECTING COVERAGE INFORMATION ON THE DESIGN POINTS
for (i=1;i<=5;i=i+1)
    for (j=1;j<=4;j=j+1)  ct(i,j) = 0
for (j=1;j<=nobs;j=j+1) {
    #   OVERALL ESTIMATE:  POSTERIOR MEAN
    dwk(1) = y(j) - 10.d0**nlaht * c(j)
    #   OVERALL ESTIMATE:  POSTERIOR STANDARD DEVIATION
    call  dsymv ('u', nnull, 1.d0, sms, nnull, s(j,1), nobs, 0.d0, ywk, 1)
    dwk(2) = (qwk(j,j,1) - ddot (nobs, qwk(1,j,1), 1, cr(1,j,1), 1))_
             + ddot (nnull, s(j,1), nobs, ywk, 1)_
             - 2.d0 * ddot (nnull, s(j,1), nobs, dr(1,j,1), 1)
    dwk(2) = dsqrt (b*dwk(2))
    #   OVERALL ESTIMATE:  COVERAGE (NO. OF POINTS OUT)
    if ( dabs (f(j,1)-dwk(1)) > dwk(2)*1.9604d0 )  ct(1,1) = ct(1,1) + 1  # 95%
    if ( dabs (f(j,1)-dwk(1)) > dwk(2)*1.6452d0 )  ct(1,2) = ct(1,2) + 1  # 90%
    if ( dabs (f(j,1)-dwk(1)) > dwk(2)*1.1504d0 )  ct(1,3) = ct(1,3) + 1  # 75%
    if ( dabs (f(j,1)-dwk(1)) > dwk(2)*0.6742d0 )  ct(1,4) = ct(1,4) + 1  # 50%

    for (i=2;i<=5;i=i+1) {
        #   COMPONENTS:  POSTERIOR MEANS
        dwk((i-1)*2+1) = s(j,i) * d(i) + ddot (nobs, qwk(1,j,i), 1, c, 1)
        #   COMPONENTS:  POSTERIOR STANDARD DEVIATIONS
        dwk(i*2) = (qwk(j,j,i) - ddot (nobs, qwk(1,j,i), 1, cr(1,j,i), 1))_
                  + s(j,i) * s(j,i) * sms(i,i) - 2.d0 * s(j,i) * dr(i,j,i)
        dwk(i*2) = dsqrt (b*dwk(i*2))
        #   COMPONENTS:  COVERAGES (NO. OF POINTS OUT)
        if ( dabs (f(j,i)-dwk(i*2-1)) > dwk(i*2)*1.9604d0 )  ct(i,1) = ct(i,1) + 1  # 95%
        if ( dabs (f(j,i)-dwk(i*2-1)) > dwk(i*2)*1.6452d0 )  ct(i,2) = ct(i,2) + 1  # 90%
        if ( dabs (f(j,i)-dwk(i*2-1)) > dwk(i*2)*1.1504d0 )  ct(i,3) = ct(i,3) + 1  # 75%
        if ( dabs (f(j,i)-dwk(i*2-1)) > dwk(i*2)*0.6742d0 )  ct(i,4) = ct(i,4) + 1  # 50%
    }

#   UNBLOCK THE FOLLOWING SEGMENT TO OUTPUT MARGINAL DESIGNS, TEST MAIN EFFECTS, 
#   POSTERIOR MEANS OF MAIN EFFECTS, AND POSTERIOR STANDARD DEVIATIONS OF MAIN EFFECTS
#    write (*,*)  (sngl (x(j,i)),i=1,3),_    #   marginal designs
#                 (sngl (f(j,i)),i=2,4),_    #   test main effects
#                 (sngl (dwk(i*2-1)),i=2,4),_#   posterior means
#                 (sngl (dwk(i*2)),i=2,4)    #   posterior stds
#    write (*,*)

}

#   OUTPUT COVERAGE INFORMATION, VAR ESTIMATE, AND ERROR CHECK (from dmudr)
                                                     # NO. OF UNCOVERED DATA POINTS
for (j=1;j<=4;j=j+1)  write (*,*)  (ct(i,j), i=1,5)  # ROWS:    95%, 90%, 75%, 50%
                                                     # COLUMNS: f, f1, f2, f3, f12
write (*,*)  sngl (dsqrt (varht)), infosv   # SIGMA HAT, info FROM dmudr

}   #   END OF REPLICATION

stop
end


#   TEST MAIN EFFECTS
double precision function  dfm (x, m)
double precision  x
integer           m

switch (m) {
    case 1 :
        dfm = dexp (3.d0 * x) - (dexp (3.d0) - 1.d0) / 3.d0
    case 2 :
        dfm = 1.d6 * (x ** 11 * (1 - x) ** 6) + 1.d4 * (x ** 3 * (1 - x) ** 10) - 6.986477575d0
    default :
        dfm = 0.d0
} 

return
end 


#   TEST INTERACTION
double precision function  dfi (x1, x2, m1, m2)
double precision  x1, x2, pi
integer           m1, m2

pi = 4.d0 * datan (1.d0)
dfi = 0.d0
if ( m1 == 1 & m2 == 2 ) {
    dfi = 5.d0 * dcos (2.d0*pi*(x1-x2))
}

return
end 


#   REPRODUCING KERNEL FOR CUBIC SPLINE ON [0,1]
double precision function  rc (y,x)
double precision  y, x, dk2, dk4

rc = dk2 (y) * dk2 (x) - dk4 (x-y)

return
end


#   AUXILIARY FUNCTION FOR CALCULATING REPRODUCING KERNEL
double precision function  dk2 (x)
double precision  x

x = dabs (x)
dk2 = ( x - .5d0 ) ** 2 
dk2 = ( dk2 - 1.d0 / 12.d0 ) / 2.d0

return
end


#   AUXILIARY FUNCTION FOR CALCULATING REPRODUCING KERNEL
double precision function  dk4 (x)
double precision  x

x = dabs (x)
dk4 = ( x - .5d0 ) ** 2
dk4 = ( dk4 ** 2 - dk4 / 2.d0 + 7.d0 / 240.d0 ) / 24.d0

return
end
